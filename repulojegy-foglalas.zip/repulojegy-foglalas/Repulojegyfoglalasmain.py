from abc import ABC, abstractmethod

# 1. Járat (absztrakt osztály)
class Jarat(ABC):
    def __init__(self, jaratszam, celallomas, jegyar):
        self.jaratszam = jaratszam
        self.celallomas = celallomas
        self.jegyar = jegyar

    @abstractmethod
    def jarat_tipus(self):
        pass

# 2. BelföldiJarat osztály
class BelfoldiJarat(Jarat):
    def jarat_tipus(self):
        return "Belföldi"

# 3. NemzetkoziJarat osztály
class NemzetkoziJarat(Jarat):
    def jarat_tipus(self):
        return "Nemzetközi"

# 4. LégiTársaság osztály
class LegiTarsasag:
    def __init__(self, nev):
        self.nev = nev
        self.jaratok = []

    def jarat_hozzaadasa(self, jarat):
        self.jaratok.append(jarat)

    def jarat_keresese(self, jaratszam):
        for jarat in self.jaratok:
            if jarat.jaratszam == jaratszam:
                return jarat
        return None

# 5. JegyFoglalás osztály
class JegyFoglalas:
    def __init__(self, utas_nev, jarat):
        self.utas_nev = utas_nev
        self.jarat = jarat

# Foglalási Rendszer
class FoglalasiRendszer:
    def __init__(self):
        self.legi_tarsasagok = []
        self.foglalasok = []
        self.elotoltes()

    def elotoltes(self):
        lt1 = LegiTarsasag("SkyHungary")
        lt2 = LegiTarsasag("GlobalWings")
        lt3 = LegiTarsasag("EuroJet")

        j1 = BelfoldiJarat("SH100", "Szeged", 9000)
        j2 = BelfoldiJarat("SH101", "Pécs", 11000)
        j3 = NemzetkoziJarat("GW200", "Párizs", 75000)
        j4 = NemzetkoziJarat("GW201", "New York", 180000)
        j5 = NemzetkoziJarat("EJ300", "Berlin", 67000)

        lt1.jarat_hozzaadasa(j1)
        lt1.jarat_hozzaadasa(j2)
        lt2.jarat_hozzaadasa(j3)
        lt2.jarat_hozzaadasa(j4)
        lt3.jarat_hozzaadasa(j5)

        self.legi_tarsasagok.extend([lt1, lt2, lt3])

        self.foglalasok.extend([
            JegyFoglalas("Kovács László", j1),
            JegyFoglalas("Nagy Júlia", j3),
            JegyFoglalas("Tóth Dániel", j5),
            JegyFoglalas("Szabó Réka", j2),
            JegyFoglalas("Kiss Balázs", j4),
            JegyFoglalas("Varga Gábor", j3)
        ])

    def foglalas(self, utas_nev, jaratszam):
        for lt in self.legi_tarsasagok:
            jarat = lt.jarat_keresese(jaratszam)
            if jarat:
                foglalas = JegyFoglalas(utas_nev, jarat)
                self.foglalasok.append(foglalas)
                print(f"Sikeres foglalás: {utas_nev} -> {jarat.celallomas}, Ár: {jarat.jegyar} Ft")
                return
        print("Hiba: ilyen járatszám nem található egyik légitársaságnál sem.")

    def lemondas(self, utas_nev, jaratszam):
        for f in self.foglalasok:
            if f.utas_nev == utas_nev and f.jarat.jaratszam == jaratszam:
                self.foglalasok.remove(f)
                print(f"Lemondás sikeres: {utas_nev} -> {f.jarat.celallomas}")
                return
        print("Hiba: ilyen foglalás nem található.")

    def listazas(self):
        if not self.foglalasok:
            print("Jelenleg nincs aktív foglalás.")
            return
        for f in self.foglalasok:
            print(f"{f.utas_nev} -> {f.jarat.celallomas} ({f.jarat.jaratszam}, {f.jarat.jarat_tipus()}) - {f.jarat.jegyar} Ft")

# Felhasználói interfész

def main():
    rendszer = FoglalasiRendszer()
    while True:
        try:
            print("\n1. Jegy foglalása\n2. Foglalás lemondása\n3. Foglalások listázása\n4. Kilépés")
            valasztas = input("Válassz egy lehetőséget: ")
            if valasztas == "1":
                nev = input("Add meg az utas nevét: ")
                jaratszam = input("Add meg a járatszámot: ")
                rendszer.foglalas(nev, jaratszam)
            elif valasztas == "2":
                nev = input("Add meg az utas nevét: ")
                jaratszam = input("Add meg a járatszámot: ")
                rendszer.lemondas(nev, jaratszam)
            elif valasztas == "3":
                rendszer.listazas()
            elif valasztas == "4":
                print("Kilépés... Viszlát!")
                break
            else:
                print("Hibás választás, próbáld újra.")
        except (EOFError, KeyboardInterrupt):
            print("\nKilépés megszakítás miatt.")
            break

if __name__ == "__main__":
    main()
